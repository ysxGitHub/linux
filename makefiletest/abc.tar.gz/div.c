#include <stdio.h>

double div1(int a, int b){
    return (double)a/b;
}
