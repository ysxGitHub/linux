#include <stdio.h>

int add1(int a, int b){
    return a+b;
}
