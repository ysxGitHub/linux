#include <stdio.h>

int mult1(int a, int b){
    return a*b;
}
