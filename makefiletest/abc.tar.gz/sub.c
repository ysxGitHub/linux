#include <stdio.h>

int sub1(int a, int b){
    return a-b;
}
